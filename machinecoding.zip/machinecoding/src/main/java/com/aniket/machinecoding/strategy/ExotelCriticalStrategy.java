package com.aniket.machinecoding.strategy;

import com.aniket.machinecoding.model.Alert;
import com.aniket.machinecoding.model.Notification;

public class ExotelCriticalStrategy implements ExotelStrategy{
    @Override
    public void performFunctionality(Alert alert) {

        Notification notification = new Notification();

//        notification.

    }
}
