package com.aniket.machinecoding.service;

import com.aniket.machinecoding.dto.AlertRequest;
import com.aniket.machinecoding.dto.AlertResponse;

public interface AlertService {

    AlertResponse createNewAlert(AlertRequest request);

}
