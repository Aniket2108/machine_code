package com.aniket.machinecoding.dto;

import com.aniket.machinecoding.model.Severity;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AlertResponse {

    private Long id;

    private String serviceId;

    private Severity severity;

    private String title;

    private String description;

    private String dedupKey;

    private LocalDateTime timeStamp;

}
