package com.aniket.machinecoding.controller;

import com.aniket.machinecoding.dto.AlertRequest;
import com.aniket.machinecoding.service.AlertService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/alert")
@Validated
@Slf4j
public class AlertController {

    private final AlertService alertService;

    public AlertController(AlertService alertService) {
        this.alertService = alertService;
    }

    @PostMapping
    public ResponseEntity<?> createNewAlert(@RequestBody @Valid AlertRequest alertRequest){
        System.out.println(alertRequest.getTimeStamp());
        return ResponseEntity.status(HttpStatus.CREATED).body(alertService.createNewAlert(alertRequest));
    }

}
