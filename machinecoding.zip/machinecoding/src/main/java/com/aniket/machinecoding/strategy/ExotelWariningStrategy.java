package com.aniket.machinecoding.strategy;

import com.aniket.machinecoding.model.Alert;

public class ExotelWariningStrategy implements ExotelStrategy{

    @Override
    public void performFunctionality(Alert alert) {

    }

}
