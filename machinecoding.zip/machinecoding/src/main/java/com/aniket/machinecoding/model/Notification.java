package com.aniket.machinecoding.model;

import lombok.Data;

@Data
public class Notification {

    private String chanel;

    private Status status;

    private String providerCallerId;

    private String lastError;

}


//"notification": {
//    "channel": "PHONE",
//            "status": "SENT", // SENT | FAILED | SKIPPED
//            "providerCallId": "CA-7781", // from the provider on success, else null
//            "lastError": null // short reason when FAILED
