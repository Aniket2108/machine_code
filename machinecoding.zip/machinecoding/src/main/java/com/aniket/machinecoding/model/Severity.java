package com.aniket.machinecoding.model;

public enum Severity {
    CRITICAL,
    INFO,
    WARNING
}
