package com.aniket.machinecoding.repository;

import com.aniket.machinecoding.model.Alert;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Repository
@Slf4j
public class AlertRepositoryImpl implements AlertRepository{

    private final Map<Long, Alert> alerts;
    private final AtomicLong id;


    public AlertRepositoryImpl() {
       alerts = new ConcurrentHashMap<>();
       id = new AtomicLong(1);
    }


    public Alert createNewAlert(Alert alert){
        log.info("in repo's createNewAlert method");
        long generatedId = id.getAndIncrement();

        alert.setId(generatedId);

        alerts.put(generatedId,alert);

        return alert;
    }
}
