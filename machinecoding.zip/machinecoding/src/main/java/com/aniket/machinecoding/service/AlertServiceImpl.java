package com.aniket.machinecoding.service;

import com.aniket.machinecoding.dto.AlertRequest;
import com.aniket.machinecoding.dto.AlertResponse;
import com.aniket.machinecoding.model.Alert;
import com.aniket.machinecoding.model.Severity;
import com.aniket.machinecoding.repository.AlertRepository;
import com.aniket.machinecoding.strategy.ExotelCriticalStrategy;
import com.aniket.machinecoding.strategy.ExotelInfoStrategy;
import com.aniket.machinecoding.strategy.ExotelStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AlertServiceImpl implements AlertService{

    private final AlertRepository alertRepository;

    public AlertServiceImpl(AlertRepository alertRepository) {
        this.alertRepository = alertRepository;
    }


    @Override
    public AlertResponse createNewAlert(AlertRequest request) {
        log.info("in service's createNewAlert method");
        if(request.getSeverity() == Severity.CRITICAL){
            ExotelStrategy exoCriticalStrategy = new ExotelCriticalStrategy();
//            exoCriticalStrategy.performFunctionality(alert);
        }
        else if(request.getSeverity() == Severity.WARNING){
            ExotelStrategy exoCriticalStrategy = new ExotelInfoStrategy();
        }
        else{
            ExotelStrategy exoCriticalStrategy = new ExotelInfoStrategy();
        }
        return entityToResponse(alertRepository.createNewAlert(requestToEntity(request)));
    }

    private AlertResponse entityToResponse(Alert newAlert) {

        AlertResponse response = new AlertResponse();

        response.setId(newAlert.getId());
        response.setServiceId(newAlert.getServiceId());
        response.setSeverity(newAlert.getSeverity());
        response.setTitle(newAlert.getTitle());
        response.setDescription(newAlert.getDescription());
        response.setDedupKey(newAlert.getDedupKey());
        response.setTimeStamp(newAlert.getTimeStamp());

        return response;

    }

    private Alert requestToEntity(AlertRequest request) {
        log.info("in requestToEntity method");
        Alert alert = new Alert();

        alert.setSeverity(request.getSeverity());
        alert.setServiceId(request.getServiceId());
        alert.setDescription(request.getDescription());
        alert.setTitle(request.getTitle());
        alert.setTimeStamp(request.getTimeStamp());
        alert.setDedupKey(request.getDedupKey());

        return alert;
    }
}
