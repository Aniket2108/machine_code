package com.aniket.machinecoding.model;

public enum Status {
    SENT,
    FAILED,
    SKIPPED
}
