package com.aniket.machinecoding.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Alert {

    private Long id;

    private String serviceId;

    private Severity severity;

    private String title;

    private String description;

    private String dedupKey;

    private LocalDateTime timeStamp;

}

