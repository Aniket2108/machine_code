package com.aniket.machinecoding.strategy;

import com.aniket.machinecoding.model.Alert;

public interface ExotelStrategy {

    void performFunctionality(Alert alert);

}
