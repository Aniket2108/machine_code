package com.aniket.machinecoding.dto;

import com.aniket.machinecoding.model.Severity;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AlertRequest {

    @NotBlank
    private String serviceId;

    private Severity severity;

    @NotBlank
    private String title;

    @NotBlank
    private String description;

    @NotBlank
    private String dedupKey;

    private LocalDateTime timeStamp;

}

