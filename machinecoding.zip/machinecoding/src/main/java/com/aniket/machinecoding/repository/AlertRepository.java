package com.aniket.machinecoding.repository;

import com.aniket.machinecoding.model.Alert;

public interface AlertRepository {

    Alert createNewAlert(Alert alert);

}
