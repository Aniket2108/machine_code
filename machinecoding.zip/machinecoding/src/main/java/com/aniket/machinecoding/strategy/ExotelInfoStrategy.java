package com.aniket.machinecoding.strategy;

import com.aniket.machinecoding.model.Alert;

public class ExotelInfoStrategy implements ExotelStrategy{

    @Override
    public void performFunctionality(Alert alert) {

    }

}
